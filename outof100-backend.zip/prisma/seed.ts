import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const listSlug = "greatest-film-of-all-time";

  const list = await prisma.list.upsert({
    where: { slug: listSlug },
    update: { title: "Greatest Film of All Time", isFeatured: true, category: "film" },
    create: {
      slug: listSlug,
      title: "Greatest Film of All Time",
      description: "Early rankings — help shape the consensus over time.",
      category: "film",
      isFeatured: true
    }
  });

  const films = [
    { slug: "the-godfather", name: "The Godfather", year: "1972" },
    { slug: "the-godfather-part-ii", name: "The Godfather Part II", year: "1974" },
    { slug: "citizen-kane", name: "Citizen Kane", year: "1941" },
    { slug: "vertigo", name: "Vertigo", year: "1958" },
    { slug: "seven-samurai", name: "Seven Samurai", year: "1954" },
    { slug: "two-thousand-and-one-a-space-odyssey", name: "2001: A Space Odyssey", year: "1968" },
    { slug: "pulp-fiction", name: "Pulp Fiction", year: "1994" },
    { slug: "apocalypse-now", name: "Apocalypse Now", year: "1979" },
    { slug: "parasite", name: "Parasite", year: "2019" },
    { slug: "spirited-away", name: "Spirited Away", year: "2001" }
  ];

  for (const f of films) {
    const item = await prisma.item.upsert({
      where: { slug: f.slug },
      update: {},
      create: {
        slug: f.slug,
        name: f.name,
        type: "votable",
        description: `Film (${f.year}).`
      }
    });

    await prisma.listItem.upsert({
      where: { listId_itemId: { listId: list.id, itemId: item.id } },
      update: { baselineScore: 70 },
      create: { listId: list.id, itemId: item.id, baselineScore: 70 }
    });

    // seed aggregates to avoid empty UI
    await prisma.aggregate.upsert({
      where: { listId_itemId: { listId: list.id, itemId: item.id } },
      update: {},
      create: {
        listId: list.id,
        itemId: item.id,
        scoreDisplay: 70,
        scoreInternal: 70,
        confidence: "low",
        voteCount: 0
      }
    });
  }

  console.log("Seed complete:", { list: list.slug, items: films.length });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
