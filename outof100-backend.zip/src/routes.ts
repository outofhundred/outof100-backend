import express from "express";
import { z } from "zod";
import { prisma } from "./prisma.js";
import { env } from "./env.js";
import { bayesianScore, confidenceFromVotes, clampScore } from "./scoring.js";

export const router = express.Router();

router.get("/health", (_req, res) => res.json({ ok: true }));

router.get("/lists", async (_req, res) => {
  const lists = await prisma.list.findMany({
    orderBy: [{ isFeatured: "desc" }, { updatedAt: "desc" }],
    select: { slug: true, title: true, description: true, category: true, isFeatured: true, updatedAt: true }
  });
  res.json({ lists });
});

router.get("/lists/:slug", async (req, res) => {
  const slug = req.params.slug;
  const list = await prisma.list.findUnique({ where: { slug } });
  if (!list) return res.status(404).json({ error: "List not found" });

  const rows = await prisma.aggregate.findMany({
    where: { listId: list.id },
    include: { item: true },
    orderBy: [{ scoreInternal: "desc" }, { voteCount: "desc" }, { item: { name: "asc" } }]
  });

  res.json({
    list: {
      slug: list.slug,
      title: list.title,
      description: list.description,
      category: list.category,
      updatedAt: list.updatedAt
    },
    items: rows.map((r, idx) => ({
      rank: idx + 1,
      item: {
        slug: r.item.slug,
        name: r.item.name,
        description: r.item.description,
        imageUrl: r.item.imageUrl
      },
      score: r.scoreDisplay,
      voteCount: r.voteCount,
      confidence: r.confidence
    }))
  });
});

router.get("/items/:slug", async (req, res) => {
  const slug = req.params.slug;
  const item = await prisma.item.findUnique({ where: { slug } });
  if (!item) return res.status(404).json({ error: "Item not found" });

  const aggregates = await prisma.aggregate.findMany({
    where: { itemId: item.id },
    include: { list: true },
    orderBy: [{ scoreInternal: "desc" }, { voteCount: "desc" }]
  });

  res.json({
    item: {
      slug: item.slug,
      name: item.name,
      description: item.description,
      imageUrl: item.imageUrl,
      imageAttribution: item.imageAttribution
    },
    rankings: aggregates.map((a) => ({
      list: { slug: a.list.slug, title: a.list.title },
      score: a.scoreDisplay,
      voteCount: a.voteCount,
      confidence: a.confidence
    }))
  });
});

router.get("/search", async (req, res) => {
  const q = String(req.query.q ?? "").trim();
  if (!q) return res.json({ items: [], lists: [], facts: [] });

  const [items, lists] = await Promise.all([
    prisma.item.findMany({
      where: { name: { contains: q, mode: "insensitive" } },
      take: 10,
      select: { slug: true, name: true, description: true }
    }),
    prisma.list.findMany({
      where: { title: { contains: q, mode: "insensitive" } },
      take: 10,
      select: { slug: true, title: true, description: true }
    })
  ]);

  res.json({ items, lists, facts: [] });
});

const voteSchema = z.object({
  listSlug: z.string().min(1),
  itemSlug: z.string().min(1),
  score: z.number().int().min(0).max(100),
  hasUsed: z.boolean().optional(),
  clientId: z.string().min(8).max(128).optional()
});

router.post("/votes", async (req, res) => {
  const parsed = voteSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const { listSlug, itemSlug, score, hasUsed = false, clientId } = parsed.data;

  const [list, item] = await Promise.all([
    prisma.list.findUnique({ where: { slug: listSlug } }),
    prisma.item.findUnique({ where: { slug: itemSlug } })
  ]);

  if (!list || !item) return res.status(404).json({ error: "List or item not found" });

  // cooldown check (anonymous via clientId)
  if (clientId) {
    const cutoff = new Date(Date.now() - env.VOTE_COOLDOWN_HOURS * 60 * 60 * 1000);
    const recent = await prisma.vote.findFirst({
      where: { clientId, listId: list.id, itemId: item.id, createdAt: { gt: cutoff } },
      orderBy: { createdAt: "desc" }
    });
    if (recent) {
      return res.status(429).json({
        error: "Cooldown active",
        retryAfterHours: env.VOTE_COOLDOWN_HOURS
      });
    }
  }

  await prisma.vote.create({
    data: {
      listId: list.id,
      itemId: item.id,
      score,
      hasUsed,
      clientId: clientId ?? null
    }
  });

  // recompute aggregate for this list-item (MVP: simple mean of all votes)
  const votes = await prisma.vote.findMany({
    where: { listId: list.id, itemId: item.id },
    select: { score: true }
  });

  const v = votes.length;
  const mean = v ? votes.reduce((s, r) => s + r.score, 0) / v : 0;

  const listItem = await prisma.listItem.findUnique({
    where: { listId_itemId: { listId: list.id, itemId: item.id } }
  });

  const C = listItem?.baselineScore ?? env.BAYES_C;
  const internal = clampScore(bayesianScore(mean, v, env.BAYES_M, C));
  const display = Math.round(internal);
  const confidence = confidenceFromVotes(v);

  await prisma.aggregate.upsert({
    where: { listId_itemId: { listId: list.id, itemId: item.id } },
    update: { scoreInternal: internal, scoreDisplay: display, voteCount: v, confidence, lastUpdated: new Date() },
    create: { listId: list.id, itemId: item.id, scoreInternal: internal, scoreDisplay: display, voteCount: v, confidence }
  });

  res.json({ ok: true, score: display, voteCount: v, confidence });
});

const suggestItemSchema = z.object({
  name: z.string().min(2),
  category: z.string().optional(),
  externalLink: z.string().url().optional(),
  note: z.string().max(500).optional()
});

router.post("/suggest/item", async (req, res) => {
  const parsed = suggestItemSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const created = await prisma.itemSuggestion.create({ data: parsed.data });
  res.json({ ok: true, suggestionId: created.id });
});

const suggestListSchema = z.object({
  title: z.string().min(3),
  category: z.string().optional(),
  description: z.string().max(800).optional(),
  exampleItems: z.string().max(800).optional()
});

router.post("/suggest/list", async (req, res) => {
  const parsed = suggestListSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const created = await prisma.listSuggestion.create({ data: parsed.data });
  res.json({ ok: true, suggestionId: created.id });
});

// Minimal admin moderation endpoints (token-based) - optional for now
router.get("/admin/suggestions", async (req, res) => {
  const token = String(req.headers["x-admin-token"] ?? "");
  if (token !== env.ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });

  const [items, lists] = await Promise.all([
    prisma.itemSuggestion.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
    prisma.listSuggestion.findMany({ orderBy: { createdAt: "desc" }, take: 100 })
  ]);

  res.json({ items, lists });
});

const adminUpdateSchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["pending", "approved", "rejected"])
});

router.post("/admin/suggestions/item/status", async (req, res) => {
  const token = String(req.headers["x-admin-token"] ?? "");
  if (token !== env.ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });

  const parsed = adminUpdateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  await prisma.itemSuggestion.update({ where: { id: parsed.data.id }, data: { status: parsed.data.status } });
  res.json({ ok: true });
});

router.post("/admin/suggestions/list/status", async (req, res) => {
  const token = String(req.headers["x-admin-token"] ?? "");
  if (token !== env.ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });

  const parsed = adminUpdateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  await prisma.listSuggestion.update({ where: { id: parsed.data.id }, data: { status: parsed.data.status } });
  res.json({ ok: true });
});
