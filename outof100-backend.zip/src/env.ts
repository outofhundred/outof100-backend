import dotenv from "dotenv";
dotenv.config();

function must(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export const env = {
  DATABASE_URL: must("DATABASE_URL"),
  PORT: parseInt(process.env.PORT ?? "8080", 10),
  CORS_ORIGIN: process.env.CORS_ORIGIN ?? "http://localhost:3000",
  BAYES_M: parseFloat(process.env.BAYES_M ?? "20"),
  BAYES_C: parseFloat(process.env.BAYES_C ?? "70"),
  VOTE_COOLDOWN_HOURS: parseInt(process.env.VOTE_COOLDOWN_HOURS ?? "24", 10),
  ADMIN_TOKEN: process.env.ADMIN_TOKEN ?? "change-me"
};
