import express from "express";
import cors from "cors";
import { router } from "./routes.js";
import { env } from "./env.js";

const app = express();

app.use(express.json({ limit: "1mb" }));

app.use(
  cors({
    origin: env.CORS_ORIGIN === "*" ? true : env.CORS_ORIGIN,
    credentials: false
  })
);

app.use("/api", router);

app.listen(env.PORT, () => {
  console.log(`OutOf100 API running on :${env.PORT}`);
});
