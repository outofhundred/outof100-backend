import { ConfidenceLevel } from "@prisma/client";

export function bayesianScore(mean: number, v: number, m: number, C: number): number {
  // (v/(v+m))*mean + (m/(v+m))*C
  if (v <= 0) return C;
  const w = v / (v + m);
  return w * mean + (1 - w) * C;
}

export function confidenceFromVotes(voteCount: number): ConfidenceLevel {
  if (voteCount >= 100) return "high";
  if (voteCount >= 20) return "medium";
  return "low";
}

export function clampScore(score: number): number {
  if (Number.isNaN(score)) return 0;
  return Math.max(0, Math.min(100, score));
}
