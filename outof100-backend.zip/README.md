# OutOf100 Backend (vertical slice)

Node.js + TypeScript + Express + Prisma + Postgres.

## Local dev
1. Copy `.env.example` to `.env` and set `DATABASE_URL`.
2. Install deps:
   - `npm i`
3. Generate Prisma client:
   - `npm run prisma:generate`
4. Create tables (pick one):
   - **Recommended:** `npx prisma migrate dev --name init`
   - or quick (no migrations): `npm run prisma:push`
5. Seed:
   - `npm run seed`
6. Run:
   - `npm run dev`

## Deploy notes (Railway)
- Set `DATABASE_URL`
- Set `CORS_ORIGIN` to your Vercel URL (or `*` temporarily)
- Build command: `npm run prisma:generate && npm run build`
- Start command: `npm run prisma:migrate && npm start`
